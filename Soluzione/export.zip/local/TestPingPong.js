//Load the header-metadata API
var hm = require('header-metadata');
//set header
hm.current.set("Content-Type", "application/json");
//Load service metadata
var sm = require('service-metadata');
var errorString = sm.getVar('var://service/error-message');
var jsonObj= {
"Pingo": "Pong"
} ;
session.output.write(jsonObj);